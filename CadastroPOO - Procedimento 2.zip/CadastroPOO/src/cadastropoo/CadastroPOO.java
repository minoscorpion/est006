package cadastropoo;

import model.PessoaFisica;
import model.PessoaJuridica;
import model.PessoaFisicaRepo;
import model.PessoaJuridicaRepo;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

import java.io.IOException;
import java.util.Scanner;
/**
 *
 * @author rafae
 */
public class CadastroPOO {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            PessoaFisicaRepo repoFisica = new PessoaFisicaRepo();
            PessoaJuridicaRepo repoJuridica = new PessoaJuridicaRepo();
            int opcao;
            
            do {
                System.out.println("Escolha uma opcao:");
                System.out.println("1 - Incluir");
                System.out.println("2 - Alterar");
                System.out.println("3 - Excluir");
                System.out.println("4 - Exibir pelo ID");
                System.out.println("5 - Exibir todos");
                System.out.println("6 - Salvar dados");
                System.out.println("7 - Recuperar dados");
                System.out.println("0 - Sair");
                opcao = scanner.nextInt();
                scanner.nextLine(); // Limpa o buffer
                
                switch (opcao) {
                    case 1 -> {
                        // Incluir
                        System.out.println("Escolha o tipo: 1 - Física, 2 - Jurídica");
                        int tipoInclusao = scanner.nextInt();
                        scanner.nextLine(); // Limpa o buffer
                        
                        if (tipoInclusao == 1) {
                            // Incluir Pessoa Física
                            System.out.println("Informe o ID, Nome, CPF e Idade:");
                            int id = scanner.nextInt();
                            scanner.nextLine(); // Limpa o buffer
                            String nome = scanner.nextLine();
                            String cpf = scanner.nextLine();
                            int idade = scanner.nextInt();
                            repoFisica.inserir(new PessoaFisica(id, nome, cpf, idade));
                        } else if (tipoInclusao == 2) {
                            // Incluir Pessoa Jurídica
                            System.out.println("Informe o ID, Nome e CNPJ:");
                            int id = scanner.nextInt();
                            scanner.nextLine(); // Limpa o buffer
                            String nome = scanner.nextLine();
                            String cnpj = scanner.nextLine();
                            repoJuridica.inserir(new PessoaJuridica(id, nome, cnpj));
                        }
                    }
                        
                    case 2 -> {
                        // Alterar
                        System.out.println("Escolha o tipo: 1 - Fisica, 2 - Juridica");
                        int tipoAlteracao = scanner.nextInt();
                        scanner.nextLine(); // Limpa o buffer
                        System.out.println("Informe o ID:");
                        int idAlterar = scanner.nextInt();
                        scanner.nextLine(); // Limpa o buffer
                        
                        if (tipoAlteracao == 1) {
                            // Alterar Pessoa Física
                            PessoaFisica pessoaFisica = repoFisica.obter(idAlterar);
                            if (pessoaFisica != null) {
                                System.out.println("Dados atuais: " + pessoaFisica);
                                System.out.println("Informe os novos dados (Nome, CPF, Idade):");
                                String nome = scanner.nextLine();
                                String cpf = scanner.nextLine();
                                int idade = scanner.nextInt();
                                pessoaFisica.setNome(nome);
                                pessoaFisica.setCpf(cpf);
                                pessoaFisica.setIdade(idade);
                            }
                        } else if (tipoAlteracao == 2) {
                            // Alterar Pessoa Jurídica
                            PessoaJuridica pessoaJuridica = repoJuridica.obter(idAlterar);
                            if (pessoaJuridica != null) {
                                System.out.println("Dados atuais: " + pessoaJuridica);
                                System.out.println("Informe os novos dados (Nome, CNPJ):");
                                String nome = scanner.nextLine();
                                String cnpj = scanner.nextLine();
                                pessoaJuridica.setNome(nome);
                                pessoaJuridica.setCnpj(cnpj);
                            }
                        }
                    }
                        
                    case 3 -> {
                        // Excluir
                        System.out.println("Escolha o tipo: 1 - Física, 2 - Jurídica");
                        int tipoExclusao = scanner.nextInt();
                        scanner.nextLine(); // Limpa o buffer
                        System.out.println("Informe o ID:");
                        int idExcluir = scanner.nextInt();
                        
                        if (tipoExclusao == 1) {
                            repoFisica.excluir(idExcluir);
                        } else if (tipoExclusao == 2) {
                            repoJuridica.excluir(idExcluir);
                        }
                    }
                        
                    case 4 -> {
                        // Exibir pelo ID
                        System.out.println("Escolha o tipo: 1 - Fisica, 2 - Juridica");
                        int tipoExibicao = scanner.nextInt();
                        scanner.nextLine(); // Limpa o buffer
                        System.out.println("Informe o ID:");
                        int idExibir = scanner.nextInt();
                        
                        if (tipoExibicao == 1) {
                            PessoaFisica pessoa = repoFisica.obter(idExibir);
                            if (pessoa != null) {
                                pessoa.exibir();
                            } else {
                                System.out.println("Pessoa Fisica não encontrada.");
                            }
                        } else if (tipoExibicao == 2) {
                            PessoaJuridica pessoa = repoJuridica.obter(idExibir);
                            if (pessoa != null) {
                                pessoa.exibir();
                            } else {
                                System.out.println("Pessoa Juridica não encontrada.");
                            }
                        }
                    }
                        
                    case 5 -> {
                        // Exibir todos
                        System.out.println("Escolha o tipo: 1 - Fisica, 2 - Juridica");
                        int tipoExibirTodos = scanner.nextInt();
                        
                        if (tipoExibirTodos == 1) {
                            for (PessoaFisica p : repoFisica.obterTodos()) {
                                p.exibir();
                            }
                        } else if (tipoExibirTodos == 2) {
                            for (PessoaJuridica p : repoJuridica.obterTodos()) {
                                p.exibir();
                            }
                        }
                    }
                        
                    case 6 -> {
                        // Salvar dados
                        System.out.println("Informe o prefixo dos arquivos:");
                        String prefixoSalvar = scanner.nextLine();
                        try {
                            repoFisica.persistir(prefixoSalvar + ".fisica.bin");
                            repoJuridica.persistir(prefixoSalvar + ".juridica.bin");
                            System.out.println("Dados salvos com sucesso.");
                        } catch (IOException e) {
                            System.out.println("Erro ao salvar os dados: " + e.getMessage());
                        }
                    }
                        
                    case 7 -> {
                        // Recuperar dados
                        System.out.println("Informe o prefixo dos arquivos:");
                        String prefixoRecuperar = scanner.nextLine();
                        try {
                            repoFisica.recuperar(prefixoRecuperar + ".fisica.bin");
                            repoJuridica.recuperar(prefixoRecuperar + ".juridica.bin");
                            System.out.println("Dados recuperados com sucesso.");
                        } catch (IOException | ClassNotFoundException e) {
                            System.out.println("Erro ao recuperar os dados: " + e.getMessage());
                        }
                    }
                        
                    case 0 -> // Sair
                        System.out.println("Saindo...");
                        
                    default -> System.out.println("Opção inválida!");
                }
            } while (opcao != 0);
        } 
    }
}
